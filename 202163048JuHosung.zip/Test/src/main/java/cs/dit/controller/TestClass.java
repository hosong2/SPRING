package cs.dit.controller;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class TestClass {
	private String id;
	private String name;
}
