package cs.dit.sample;

import org.springframework.stereotype.Component;

@Component
public class Chef {

}
